// Local plan: window at z=0, entry at z=4.2; x across 2.5m.
export function addFatherStudy({T,root,box,round,cyl,line3,mat,glass,dark,steel}){
 const g=new T.Group();g.name='father-study-furniture';g.position.set(17.2,0,2.8);g.rotation.y=-Math.PI/2;root.add(g);
 const wood=mat('#806044'),fabric=mat('#b9afa3'),paper=mat('#e8dfcb'),black=mat('#303232'),cream=mat('#d5c6b2');
 const b=(x,y,z,w,h,d,m=wood)=>box(x,y,z,w,h,d,m,g);
 const r=(x,y,z,w,h,d,m=wood,rad=.035)=>round(x,y,z,w,h,d,m,rad,g);
 const c=(x,y,z,ra,h,m=wood)=>cyl(x,y,z,ra,h,m,g);
 const l=(a,b,ra,m=black)=>line3(a,b,ra,m,g);
 function oval(x,y,z,w,h,d,m){const o=new T.Mesh(new T.CylinderGeometry(1,1,h,48),m);o.scale.set(w/2,1,d/2);o.position.set(x+w/2,y+h/2,z+d/2);o.castShadow=o.receiveShadow=true;g.add(o);return o}
 // Five shallow bookcase bays; stop one metre before entry.
 b(.02,0,.15,.28,.12,3.05);b(.02,2.40,.15,.28,.06,3.05);b(.02,.12,.15,.025,2.28,3.05);
 for(let i=0;i<=5;i++)b(.02,.12,.15+i*.61,.28,2.28,.022,black);
 for(let j=0;j<5;j++){
 const z=.18+j*.61;b(.05,.12,z,.25,.63,.565);b(.303,.17,z,.012,.54,.565);b(.318,.40,z+.08,.015,.12,.018,black);
 for(const y of [.77,1.15,1.55,1.95,2.38])b(.045,y,z,.255,.025,.565);
 for(let row=0;row<4;row++)for(let k=0;k<6;k++){if(j===2&&row===2)continue;const y=.80+row*.40;const zz=z+.035+k*.082;b(.08,y,zz,.19,.21+(k%3)*.035,.052,[paper,cream,wood,black][(k+j+row)%4]);}
 b(.31,.78,z,.012,1.6,.565,glass);
 b(.32,.78,z,.012,.015,.565,black);b(.32,2.38,z,.012,.015,.565,black);
 }
 // A single small heart teaching model among books.
 const heartMat=mat('#a65b49');for(const [yy,zz,sx,sy,sz]of [[1.73,1.61,.07,.10,.075],[1.78,1.55,.065,.07,.06]]){const o=new T.Mesh(new T.SphereGeometry(1,16,12),heartMat);o.position.set(.19,yy,zz);o.scale.set(sx,sy,sz);g.add(o)}
 c(.19,1.59,1.58,.08,.025,black);l([.19,1.8,1.59],[.19,1.91,1.61],.017,mat('#607e8c'));
 b(.26,1.18,2.12,.018,.22,.17,cream);b(.28,1.20,2.14,.008,.18,.13,mat('#9caca6'));
 // Capsule desktop and compact sculptural supports.
 const shape=new T.Shape();const w=1.35,d=.65,rad=.20;shape.moveTo(rad,0);shape.lineTo(w-rad,0);shape.quadraticCurveTo(w,0,w,rad);shape.lineTo(w,d-rad);shape.quadraticCurveTo(w,d,w-rad,d);shape.lineTo(rad,d);shape.quadraticCurveTo(0,d,0,d-rad);shape.lineTo(0,rad);shape.quadraticCurveTo(0,0,rad,0);
 const geo=new T.ExtrudeGeometry(shape,{depth:.045,bevelEnabled:false,curveSegments:12});geo.rotateX(Math.PI/2);const top=new T.Mesh(geo,wood);top.position.set(1.05,.76,1.05);top.castShadow=top.receiveShadow=true;g.add(top);
 c(1.30,0,1.38,.17,.715);r(2.13,0,1.17,.24,.715,.43,wood,.04);
 // Chair on window side, facing the door.
 r(1.39,.43,.32,.62,.09,.60,fabric,.04);r(1.39,.52,.32,.62,.55,.08,fabric,.035);c(1.70,.12,.62,.035,.31,steel);
 for(let i=0;i<5;i++){const a=i*Math.PI*2/5,x=1.7+Math.cos(a)*.28,z=.62+Math.sin(a)*.28;l([1.7,.15,.62],[x,.055,z],.018,black);c(x,.02,z,.035,.045,black)}
 for(const x of [1.39,1.97]){b(x,.52,.50,.035,.15,.05,black);r(x,.67,.43,.035,.04,.31,fabric,.015)}
 // Laptop, notes, cup and desk lamp.
 b(1.51,.763,1.17,.38,.016,.26,black);b(1.51,.78,1.42,.38,.25,.016,black);b(1.53,.80,1.415,.34,.20,.006,mat('#5b7281'));
 b(1.12,.765,1.20,.20,.012,.26,paper);c(1.30,.765,1.54,.035,.065,cream);c(2.26,.765,1.45,.065,.02,black);l([2.26,.79,1.45],[2.26,1.10,1.45],.008);l([2.26,1.10,1.45],[2.08,1.16,1.43],.008);c(2.08,1.1,1.43,.05,.09,black);
 // Two-seat sofa; its back is against the south/right wall.
 r(1.80,.10,2.10,.70,.25,1.40,fabric,.06);r(2.37,.31,2.10,.13,.49,1.40,fabric,.05);
 for(const z of [2.10,3.37])r(1.80,.30,z,.70,.32,.13,fabric,.04);
 for(const z of [2.24,2.81]){r(1.82,.35,z,.54,.12,.54,cream,.05);r(2.27,.47,z,.12,.32,.54,fabric,.04)}
 oval(1.10,.34,2.47,.40,.035,.65,wood);oval(1.18,0,2.57,.24,.34,.45,wood);b(1.19,.378,2.68,.18,.012,.24,paper);
 // Curtains flank the existing 1.10m ordinary window.
 for(const start of [.48,1.81])for(let i=0;i<6;i++)c(start+i*.035,.04,.055,.025,2.42,fabric);
 // Two framed abstract/landscape-like compositions on right wall.
 for(const [z,len,h]of [[1.12,.65,.75],[2.28,.48,.90]]){b(2.465,1.22,z,.025,h,len,wood);b(2.45,1.25,z+.03,.012,h-.06,len-.06,paper);for(let i=0;i<3;i++)b(2.437,1.31+i*.12,z+.08+i*.06,.008,.12,len*.42,mat(['#7b8074','#b6a58d','#949486'][i]));}
 return g;
}
