// Parents suite: local north-west origin (13, 5.3). Metres.
export function addParents({T,root,box,round,cyl,line3,mat,oak,white,grey,glass,dark,steel}){
 const g=new T.Group();g.name='parents-suite-furniture';g.position.set(13,0,5.3);root.add(g);
 const cream=mat('#eee9df'),tile=mat('#d9cebe'),b=(x,y,z,w,h,d,m=oak)=>box(x,y,z,w,h,d,m,g),r=(x,y,z,w,h,d,m=cream,rad=.04)=>round(x,y,z,w,h,d,m,rad,g);
 // East-facing headboard and 1.8 x 2m mattress; no television.
 b(2.75,.008,3.35,2.4,.012,2.65,mat('#dcd4c6'));
 r(3.02,.12,3.65,2.16,.26,2,oak,.07);r(5.04,.25,3.65,.14,.85,2,cream,.06);
 r(3.04,.38,3.75,2,.22,1.8,white,.07);r(3.04,.6,3.75,1.53,.045,1.8,cream,.02);
 r(3.25,.65,3.73,.42,.025,1.84,grey,.01);
 for(const z of [3.87,4.78])r(4.51,.61,z,.42,.14,.65,white,.05);
 for(const z of [3.1,5.76]){b(4.68,.22,z,.5,.3,.5);cyl(4.93,.52,z+.25,.07,.22,oak,g);cyl(4.93,.74,z+.25,.13,.18,cream,g);}
 // Long shallow dresser at bed foot. Retracted projection cassette above.
 b(.05,0,3.65,.4,.75,2,oak);b(.05,.75,3.65,.4,.025,2,cream);
 for(const z of [4.31,4.97])b(.451,.05,z,.006,.64,.008,dark);
 for(const y of [.25,.5])b(.451,y,3.67,.006,.008,1.96,dark);
 b(2.1,2.5,3.545,.1,.1,2.21,white);b(4.65,2.36,4.5,.27,.13,.3,white);
 // Closet has NO entry door, partition wardrobe, or freestanding island.
 b(3.22,0,.03,2.55,2.55,.6,cream);
 for(let x=3.72;x<5.7;x+=.51)b(x,.06,.632,.009,2.42,.006,oak);
 b(5.17,0,.63,.6,.12,1.73);b(5.72,0,.63,.05,2.55,1.73);b(5.17,2.49,.63,.6,.06,1.73);
 for(const z of [.63,1.5,2.32])b(5.17,0,z,.6,2.49,.04);
 // Back bay: open hanging and lower drawers; near bay closed ivory front flush to entrance.
 b(5.17,.12,.67,.55,.52,.8);for(const y of [.28,.46])b(5.163,y,.68,.008,.008,.78,dark);
 line3([5.43,2.07,.7],[5.43,2.07,1.46],.012,steel,g);
 for(let i=0;i<7;i++)r(5.24,.91,.71+i*.105,.38,1.06,.07,[cream,grey,white][i%3],.02);
 b(5.16,.12,1.54,.018,2.33,.78,cream);b(5.14,1.05,1.6,.02,.55,.02,oak);
 // Vanity: jewelry drawers, open knee space, stool tucked below.
 b(3.24,.72,.72,.45,.12,1.05);b(3.24,.84,.72,.45,.035,1.05,cream);
 b(3.24,.05,.72,.45,.67,.035);b(3.24,.05,1.735,.45,.67,.035);
 cyl(3.45,.06,1.26,.18,.38,oak,g);cyl(3.45,.44,1.26,.19,.065,cream,g);
 b(3.235,1.04,.88,.018,.88,.72,new T.MeshStandardMaterial({color:'#b9c4c4',metalness:.85,roughness:.15}));
 // Foyer north wall: glass-front handbag display, lower closed storage.
 b(.04,0,.03,1.12,.55,.32,cream);b(.04,.55,.03,1.12,1.65,.025);
 for(const x of [.04,1.13])b(x,.55,.03,.03,1.65,.32);
 for(const y of [.55,1.08,1.61,2.17])b(.04,y,.03,1.12,.03,.32);
 b(.07,.58,.345,1.06,1.58,.012,glass);b(.59,.58,.35,.015,1.58,.015,oak);
 for(const [x,y,c]of [[.22,.59,'#e5d9c4'],[.72,.59,'#9e7758'],[.22,1.12,'#343536'],[.72,1.12,'#e7dfd1'],[.47,1.65,'#b18a66']]){
 r(x,y,.1,.25,.24,.18,mat(c),.035);
 const h=new T.Mesh(new T.TorusGeometry(.065,.012,8,24,Math.PI),mat(c));h.position.set(x+.125,y+.24,.19);g.add(h);
 }
 // Bathroom: full-width north shower, east vanity, south toilet. No window or towel rail.
 b(1.2,.005,0,2,.02,2.4,tile);b(1.22,.025,.03,1.96,.025,.97,tile);
 for(const y of [.05,2.08])b(1.22,y,.99,1.96,.025,.035,steel);
 b(1.22,.075,1,1.03,2,.014,glass);b(2.19,.075,1.025,.99,2,.014,glass);
 line3([2.2,.95,.98],[2.2,1.2,.98],.012,steel,g);
 line3([2.2,.9,.06],[2.2,2.1,.06],.014,steel,g);line3([2.2,2.1,.06],[2.2,2.1,.33],.014,steel,g);cyl(2.2,2.08,.33,.12,.025,steel,g);
 b(2.7,.22,1.05,.5,.55,.95);b(2.7,.77,1.05,.5,.06,.95,white);
 r(2.76,.831,1.25,.37,.035,.52,mat('#d0d5d2'),.04);
 line3([3.12,.83,1.5],[3.12,1.08,1.5],.014,steel,g);line3([3.12,1.08,1.5],[2.94,1.08,1.5],.014,steel,g);
 b(3.17,1.08,1.07,.025,.93,.91,new T.MeshStandardMaterial({color:'#b9c4c4',metalness:.85,roughness:.15}));
 r(2.13,.08,2.23,.4,.66,.15,white,.04);r(2.12,.05,1.78,.42,.36,.56,white,.1);r(2.11,.41,1.76,.44,.045,.57,white,.02);
 return g;
}
