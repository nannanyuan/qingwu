// B1 studio, west entrance / east window. Dimensions in metres.
export function addArtStudio({T,root,box,round,cyl,line3,mat,oak,white,grey,glass,dark,steel}){
 const g=new T.Group();g.name='artstudio-furniture';g.position.set(13,0,0);root.add(g);
 const b=(x,y,z,w,h,d,m=oak)=>box(x,y,z,w,h,d,m,g);
 const c=(x,y,z,r,h,m=oak)=>cyl(x,y,z,r,h,m,g);
 const l=(a,b,r,m)=>line3(a,b,r,m,g);
 const paper=mat('#faf6e9'),pink=mat('#c8869c'),green=mat('#73866f'),blue=mat('#8daebd'),linen=mat('#cfc6b6');
 b(1.4,.72,.05,2.75,.055,.8);b(3.5,.72,.85,.65,.055,.9);
 for(const [x,z]of [[1.44,.1],[1.44,.75],[4.03,.1],[4.03,1.6],[3.54,1.6]])b(x,0,z,.07,.72,.07);
 b(.06,.06,.05,1.3,.69,.7,white);
 for(let i=0;i<6;i++){b(.08,.08+i*.11,.755,1.26,.095,.018,white);b(.57,.12+i*.11,.778,.28,.016,.02,oak)}
 b(.06,.75,.05,1.3,.04,.7);b(.18,.79,.15,.7,.025,.45,paper);
 // Open two-row bookcase, with a continuous top rather than a front elevation on the floor.
 b(1.15,.05,2.4,2.05,.06,.4);b(1.15,1.08,2.4,2.05,.045,.4);b(1.15,.57,2.4,2.05,.035,.4);b(1.15,.05,2.77,2.05,1.03,.03);
 for(let i=0;i<=4;i++)b(1.15+i*.505,.05,2.4,.035,1.03,.4);
 for(let i=0;i<19;i++){const x=1.22+i*.1;if(i%5===4)continue;b(x,.61,2.45,.055,.29+(i%3)*.06,.27,[white,linen,grey,oak][i%4])}
 for(let i=0;i<4;i++){b(1.22+i*.5,.12,2.45,.37,.31,.3,linen);b(1.35+i*.5,.3,2.437,.1,.025,.01,dark)}
 // Single swivel task chair facing the main desk.
 round(2.05,.43,1.02,.55,.09,.52,grey,.04,g);round(2.05,.5,1.49,.55,.55,.075,grey,.03,g);c(2.325,.11,1.29,.035,.32,steel);
 for(let i=0;i<5;i++){let a=i*Math.PI*2/5,x=2.325+Math.cos(a)*.29,z=1.29+Math.sin(a)*.29;l([2.325,.16,1.29],[x,.07,z],.018,steel);c(x,.025,z,.035,.045,dark)}
 // Three-tier rolling materials trolley.
 for(const y of [.12,.42,.72])b(2.9,y,1.78,.4,.035,.45);
 for(const x of [2.92,3.25])for(const z of [1.8,2.17]){b(x,.08,z,.025,.68,.025);c(x,.025,z,.035,.055,dark)}
 for(let i=0;i<5;i++)c(2.96+i*.06,.755,1.86,.02,.12,[white,blue,pink][i%3]);
 // Easel near the window; canvas faces into the room.
 l([3.63,0,2.07],[3.7,1.65,2.56],.025,oak);l([4.05,0,2.07],[3.98,1.65,2.56],.025,oak);l([3.84,1.3,2.48],[3.86,0,2.69],.025,oak);
 b(3.57,.5,2.3,.57,.045,.1);b(3.61,.54,2.4,.49,.78,.025,paper);
 for(let i=0;i<5;i++){let x=3.68+i*.07,y=.75+(i%3)*.12;l([3.84,.57,2.384],[x,y,2.384],.003,green);c(x,y,2.38,.025,.018,pink).rotation.x=Math.PI/2}
 // Drawing papers, brushes and a compact palette.
 b(1.9,.78,.24,.65,.003,.42,paper);b(2.72,.78,.18,.32,.018,.18,white);
 for(let i=0;i<5;i++)c(2.75+i*.05,.8,.24,.016,.006,[pink,blue,green,oak,dark][i]);
 for(const x of [1.62,3.78]){c(x,.775,.3,.055,.1,grey);for(let i=0;i<5;i++)l([x,.83,.3],[x+(i-2)*.013,1.04+(i%2)*.04,.3],.003,oak)}
 function flowers(x,y,z,color){c(x,y,z,.065,.17,glass);for(let i=0;i<5;i++){const xx=x+(i-2)*.035,zz=z+(i%2)*.035,yy=y+.29+(i%3)*.04;l([x,y+.07,z],[xx,yy,zz],.003,green);const f=new T.Mesh(new T.SphereGeometry(.026,8,6),color);f.position.set(xx,yy,zz);g.add(f)}}
 flowers(1.53,.775,.16,pink);flowers(4,.775,.38,white);flowers(2.9,1.125,2.59,mat('#dbb09d'));
 // Individual framed works on both solid walls; distinct compositions.
 function artwork(x,y,z,w,h,kind){b(x,y,z,w,h,.025,oak);b(x+.025,y+.025,z-.005,w-.05,h-.05,.012,paper);for(let i=0;i<5;i++){let xx=x+.08+(i/(5))*Math.max(.1,w-.15),yy=y+.12+(i%3)*h*.17;l([x+w*.5,y+.08,z-.012],[xx,yy,z-.012],.004,kind===0?green:blue)}}
 artwork(1.45,1.3,.025,.45,.65,0);artwork(2.05,1.45,.025,.6,.42,1);artwork(3.06,1.25,.025,.42,.9,0);
 // South wall frame planes face north into room.
 artwork(1.35,1.45,2.75,.8,.42,1);artwork(2.48,1.5,2.75,.42,.58,0);
 return g;
}
