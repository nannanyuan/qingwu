import {addStorage} from './storage-details.js?v=17';
import {addFatherStudy} from './father-study-details.js?v=16';
import * as T from './assets/three.module.js';
import plan from './house-plan.js?v=14';
import {addArtStudio} from './artstudio-details.js?v=15';
import {addParents} from './parents-details.js?v=14';
import {addBedroom} from './room-details.js?v=2';
export async function createHouse(host,onPick,isActive){
 const scene=new T.Scene();scene.background=new T.Color('#eef0ed');const camera=new T.PerspectiveCamera(38,1,.1,180),renderer=new T.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;host.replaceChildren(renderer.domElement);
 scene.add(new T.HemisphereLight(0xffffff,0xb9b9ae,2.6));const sun=new T.DirectionalLight(0xffffff,3);sun.position.set(-8,30,-12);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-24,right:24,top:24,bottom:-24,far:80});sun.shadow.bias=-.0003;scene.add(sun);
 const root=new T.Group();scene.add(root);const walls=new T.Group(),labels=new T.Group();root.add(walls,labels);const targets=[];
 const mat=(c,r=.8)=>new T.MeshStandardMaterial({color:c,roughness:r});const white=mat('#f4f5f3'),oak=mat('#d3bd9d'),grey=mat('#c3cbce'),dark=mat('#39434a'),wall=mat('#e1e4df'),gold=mat('#c0a15f',.28),glass=new T.MeshStandardMaterial({color:'#c1dfe5',transparent:true,opacity:.25,roughness:.14,depthWrite:false,side:T.DoubleSide});
 function box(x,y,z,w,h,d,m,parent=root){const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x+w/2,y+h/2,z+d/2);o.castShadow=o.receiveShadow=true;parent.add(o);return o}
 function round(x,y,z,w,h,d,m,r=.04,parent=root){const g=new T.BoxGeometry(w,h,d,5,5,5),a=g.attributes.position,core=new T.Vector3(w/2-r,h/2-r,d/2-r),v=new T.Vector3(),q=new T.Vector3();for(let i=0;i<a.count;i++){v.fromBufferAttribute(a,i);q.copy(v).clamp(core.clone().negate(),core);v.sub(q).normalize().multiplyScalar(r).add(q);a.setXYZ(i,v.x,v.y,v.z)}g.computeVertexNormals();const o=new T.Mesh(g,m);o.position.set(x+w/2,y+h/2,z+d/2);o.castShadow=o.receiveShadow=true;parent.add(o);return o}
 function cyl(x,y,z,r,h,m,parent=root){const o=new T.Mesh(new T.CylinderGeometry(r,r,h,24),m);o.position.set(x,y+h/2,z);o.castShadow=true;parent.add(o);return o}
 function line3(a,b,r,m,parent=root){const v=new T.Vector3(...a),u=new T.Vector3(...b).sub(v),o=new T.Mesh(new T.CylinderGeometry(r,r,u.length(),10),m);o.position.copy(v.addScaledVector(u,.5));o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),u.normalize());parent.add(o);return o}
 function strip(s,y,h,m,parent=root,width=.13){const [x,z,xx,zz]=s;return box(Math.min(x,xx)-(x===xx?width/2:0),y,Math.min(z,zz)-(z===zz?width/2:0),Math.max(width,Math.abs(xx-x)),h,Math.max(width,Math.abs(zz-z)),m,parent)}
 function textLabel(text,x,z){const c=document.createElement('canvas');c.width=512;c.height=110;const ctx=c.getContext('2d');ctx.fillStyle='rgba(249,250,247,.94)';ctx.beginPath();ctx.roundRect(3,3,506,104,25);ctx.fill();ctx.font='32px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#405852';ctx.fillText(text,256,55);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;const sp=new T.Sprite(new T.SpriteMaterial({map:tex,depthTest:false}));sp.position.set(x,1.6,z);sp.scale.set(2.7,.58,1);sp.renderOrder=10;labels.add(sp)}
 for(const r of plan.rooms){const wet=/卫|洗衣/.test(r.n),bed=/卧室|客卧/.test(r.n);const floor=box(r.x,-.17,r.y,r.w,.17,r.h,mat(wet?'#dce4e6':bed?'#d9c7ae':r.k==='balcony'?'#dce6df':'#e8e5dc'));floor.userData={room:r};targets.push(floor);if(!/连接|连通|通行/.test(r.n))textLabel(r.n,r.x+r.w/2,r.y+r.h/2);if(bed||r.n==='许今闻书房'||r.n==='妈妈的画室'||r.n==='爸爸的书房'){for(let z=r.y+.22;z<r.y+r.h;z+=.24)box(r.x,.001,z,r.w,.003,.006,mat('#bfae96'))}}
 for(const s of plan.walls)strip(s,0,2.65,wall,walls);
 for(const s of plan.windows){const sliding=s.length===5;const kitchenWindow=Math.abs(s[1]-16.4)<.01||(s[0]>=13.6&&Math.abs(s[1]+1.8)<.01);const kitchenDoor=sliding&&s[1]>13.5&&s[1]<13.7;const sill=sliding?0:kitchenWindow?1.05:.72,h=sliding?2.25:kitchenWindow?1.35:1.7;strip(s,0,sill||.03,wall);strip(s,sill,h,kitchenDoor?new T.MeshStandardMaterial({color:0xd6dad5,transparent:true,opacity:.86,roughness:.8}):glass,root,.045);strip(s,sill,.045,dark,root,.065);strip(s,sill+h,.045,dark,root,.065);const [x,z,xx,zz]=s;for(const f of [0,.5,1])box(x+(xx-x)*f-.022,sill,z+(zz-z)*f-.022,.044,h,.044,white)}
 for(const [x,z,w,d]of plan.bays){box(x,.0,z,w,.55,d,white);if(w>d){strip([x,z+(z>10?d:0),x+w,z+(z>10?d:0)],.55,1.85,glass);strip([x,z,x,z+d],.55,1.85,glass);strip([x+w,z,x+w,z+d],.55,1.85,glass)}else{strip([x+w,z,x+w,z+d],.55,1.85,glass);strip([x,z+(z>10?d:0),x+w,z+(z>10?d:0)],.55,1.85,glass);strip([x,z+d,x+w,z+d],.55,1.85,glass)}}
 // All door leaves are closed flush within their original wall openings.
 for(const s of plan.doors){strip(s,0,2.15,oak,root,.045);const [x,z,xx,zz]=s;const hx=x+(xx-x)*.84,hz=z+(zz-z)*.84;box(hx-.035,.98,hz-.035,.07,.045,.07,dark)}
 const bedroom=new T.Group();bedroom.position.set(3.45,0,4.1);root.add(bedroom);addBedroom(bedroom);
 // Suite furniture retained in the exact architectural coordinate system.
 box(4.12,.23,1.52,.58,.54,1.14,oak);box(4.12,.77,1.52,.58,.06,1.14,white);round(4.2,.83,1.8,.42,.07,.54,white,.03);box(4.12,1,1.6,.025,.85,.8,glass);round(5.2,.05,1.55,.65,.75,.2,white,.055);round(5.22,.08,1.8,.61,.42,.72,white,.1);
 box(6.06,.015,1.5,1.24,.035,1.12,grey);strip([6.06,1.5,6.06,2.62],0,2.05,glass);strip([6.06,2.62,7.3,2.62],0,2.05,glass);line3([6.8,.8,1.57],[6.8,1.95,1.57],.015,dark);cyl(6.8,1.92,1.75,.13,.025,dark);
 function wardrobe(x,z,w,d,side){box(x,0,z,w,.12,d,oak);box(x,2.24,z,w,.1,d,white);if(side==='south')box(x,0,z+d-.04,w,2.25,.04,oak);else box(x+w-.04,0,z,.04,2.25,d,oak);const len=side==='south'?w:d;for(let t=0;t<len;t+=.6){if(side==='south'){box(x+t,0,z,.025,2.25,d,white);box(x+t,.12,z,Math.min(.57,len-t),2.1,.018,glass)}else{box(x,0,z+t,w,2.25,.025,white);box(x,.12,z+t,.018,2.1,Math.min(.57,len-t),glass)}}for(let t=.1;t<len-.1;t+=.16){const cloth=mat(['#293038','#eceeed','#b8c1cb','#aabfcd'][Math.floor(t*10)%4]);if(side==='south')round(x+t,.88,z+.15,.09,.74,.32,cloth,.025);else round(x+.15,.88,z+t,.32,.74,.09,cloth,.025)}}
 wardrobe(4.1,6.1,3.2,.6,'south');wardrobe(6.7,3.67,.6,2.43,'east');wardrobe(4.1,5,.6,1.1,'east');box(4,0,5,.12,2.2,1.8,wall,walls);box(4,0,4.96,.7,2.2,.1,wall,walls);round(5.6,0,3.67,1.1,.38,.4,oak);round(5.6,.38,3.67,1.1,.09,.4,grey);round(5.45,0,4.95,.8,.79,.4,white);for(const y of [.25,.5,.72])box(5.47,y,5.352,.76,.008,.005,dark);box(5.42,.79,4.92,.86,.035,.46,oak);box(5.72,.12,6.075,.76,1.78,.02,new T.MeshStandardMaterial({color:'#adbfc4',metalness:.9,roughness:.13}));
 // Guest room furniture: local origin is north-west, x east, z south.
 const guest=new T.Group();guest.name='guest-furniture';guest.position.set(-2,0,8.1);root.add(guest);
 const gb=(x,y,z,w,h,d,m=white)=>box(x,y,z,w,h,d,m,guest);
 const gr=(x,y,z,w,h,d,m=grey,r=.04)=>round(x,y,z,w,h,d,m,r,guest);
 const linen=mat('#d4d4d0'),throwMat=mat('#9c9f9e'),rug=mat('#d1c8ba');
 gb(.45,.005,1.05,2.75,.015,2.4,rug);
 gr(.75,.12,1.3,1.7,.28,2.2,linen,.09);
 gr(.78,.22,3.34,1.64,.9,.14,linen,.06);
 gr(.84,.4,1.36,1.52,.19,1.98,white,.07);
 gr(.83,.58,1.37,1.54,.07,1.45,linen,.03);
 gr(.81,.655,1.55,1.58,.025,.48,throwMat,.01);
 gr(.94,.6,2.94,.62,.13,.36,grey,.05);gr(1.64,.6,2.94,.62,.13,.36,grey,.05);
 gr(1.33,.71,3.02,.55,.10,.24,white,.04);
 for(const x of [.2,2.55]){gb(x,.25,3,.45,.25,.5,oak);gb(x+.015,.38,2.995,.42,.008,.008,dark);cyl(x+.225,.5,3.23,.055,.10,oak,guest);const lamp=new T.Mesh(new T.SphereGeometry(.10,24,16),white);lamp.position.set(x+.225,.69,3.23);guest.add(lamp)}
 gb(.23,.505,3.1,.13,.025,.18,white);cyl(.29,.53,3.19,.045,.035,oak,guest);
 cyl(2.9,.5,3.27,.055,.13,grey,guest);for(let i=0;i<5;i++){const x=2.9+(i-2)*.028;line3([2.9,.6,3.27],[x,.85+(i%2)*.06,3.28],.005,mat('#768875'),guest)}
 // Opaque sliding wardrobe: 2.4m long, 0.6m deep, with entry setback.
 gb(3.7,0,1.05,.6,2.58,2.4,white);for(let i=0;i<3;i++){gb(3.685,0,1.06+i*.8,.018,2.54,.785,white);gb(3.66,.8,1.12+i*.8,.025,.85,.025,oak)}
 // Artwork above headboard, on the existing solid wall.
 gb(1.04,1.43,3.46,1.12,.75,.025,oak);gb(1.065,1.455,3.445,1.07,.7,.015,mat('#d0cbc0'));gb(1.5,1.65,3.43,.35,.3,.01,mat('#a7a59d'));
 // Curtains flank the existing ordinary north window, no bay or seat.
 for(const xx of [.18,1.32])for(let i=0;i<5;i++)cyl(xx+i*.025,.08,.055,.025,2.4,grey,guest);
 // The drawing plan is rotated as one unit: its top window becomes the west window,
 // and its bottom entrance becomes the east entrance in the full apartment plan.
 const study=new T.Group();study.position.set(3.8,0,1.4);study.rotation.y=Math.PI/2;study.scale.set(3.2/3.4,1,3.6/3.4);root.add(study);
 const b=(x,y,z,w,h,d,m=white)=>box(x,y,z,w,h,d,m,study),r=(x,y,z,w,h,d,m=white,rad=.04)=>round(x,y,z,w,h,d,m,rad,study);
 r(.96,.74,.16,2.41,.055,.65);r(2.72,.74,.77,.65,.055,1.51);b(.97,.03,.19,.35,.7,.56,oak);b(2.96,.03,1.65,.38,.7,.6,oak);for(let y=.15;y<.7;y+=.18)b(2.955,y,1.67,.008,.01,.55,grey);b(3.29,.03,.3,.05,.71,1.25,oak);
 function chair(x,z,facing){const g=new T.Group();g.position.set(x,0,z);g.rotation.y=facing;study.add(g);round(-.24,.43,-.23,.48,.08,.46,grey,.035,g);round(-.24,.5,.19,.48,.43,.07,grey,.035,g);cyl(0,.1,0,.035,.33,dark,g);for(let a=0;a<5;a++){const t=a/5*Math.PI*2;line3([0,.12,0],[Math.cos(t)*.28,.05,Math.sin(t)*.28],.015,dark,g);cyl(Math.cos(t)*.28,.025,Math.sin(t)*.28,.035,.04,dark,g)}}chair(1.75,1.12,0);chair(2.37,1.62,-Math.PI/2);
 // Silver all-in-one computer; display faces west towards the computer chair.
 const silver=mat('#c9ced0',.24),screen=mat('#708d9e',.35);r(3.19,.91,1.13,.045,.46,.65,silver,.02);b(3.181,.95,1.15,.009,.37,.61,screen);b(3.12,.79,1.42,.05,.17,.065,silver);r(3.02,.793,1.34,.23,.02,.22,silver,.008);r(2.85,.799,1.23,.18,.018,.49,white,.008);r(2.83,.8,1.86,.07,.025,.1,white,.01);
 b(1.36,.798,.26,.61,.009,.43,white);b(1.66,.807,.26,.003,.002,.43,grey);for(let i=0;i<6;i++)b(2.05+i*.035,.8,.35,.025,.012,.05,mat(['#798e94','#c8b178','#9ba68b','#bc8279','#d8d8cf','#5a6570'][i]));
 // Corner easel, tilted canvas and a small art cart.
 for(const [a,c]of [[[.2,0,.7],[.48,1.7,.54]],[[.82,0,.7],[.54,1.7,.54]],[[.54,0,.21],[.54,1.55,.54]]])line3(a,c,.022,oak,study);b(.2,.63,.56,.64,.04,.07,oak);const canvas=b(.25,.67,.51,.54,.72,.035,white);canvas.rotation.x=-.1;b(.29,.73,.49,.46,.57,.01,mat('#c8d1d1'));for(let y of [.15,.4,.67])b(.08,y,1,.38,.035,.34,oak);for(let x of [.1,.42])for(let z of [1.02,1.3])line3([x,.04,z],[x,.72,z],.012,dark,study);
 // Lower-left bookcase: top-down view shows its actual cabinet top.
 b(.025,0,1.85,.34,.08,1.2,oak);b(.025,2.12,1.85,.34,.06,1.2,white);b(.025,0,1.85,.025,2.15,1.2,white);for(let z of [1.85,3.025])b(.025,0,z,.34,2.15,.025,white);for(let y of [.45,.88,1.31,1.74]){b(.025,y,1.85,.34,.025,1.2,oak);for(let i=0;i<12;i++){let h=.23+(i%4)*.035;b(.08,y+.025,1.9+i*.086,.22,h,.055,mat(['#c1c9cb','#d9d6cb','#7c8a91','#9dacae'][i%4]))}}
 // Display inventory: exactly two cups, four specimen frames (five butterflies), one certificate.
 b(3.025,0,2.28,.35,.45,.8,oak);b(3.35,.45,2.28,.025,1.82,.8,white);for(let z of [2.28,3.055])b(3.025,.45,z,.35,1.82,.025,white);b(3.025,2.25,2.28,.35,.05,.8,white);for(let y of [.46,.9,1.34,1.78])b(3.025,y,2.28,.35,.022,.8,glass);b(3.025,.45,2.28,.012,1.8,.8,glass);
 function frame(z,y,color,count=1,certificate=false){b(3.27,y,z,.028,.29,.27,certificate?oak:dark);b(3.253,y+.02,z+.02,.015,.25,.23,white);if(certificate){for(let i=0;i<5;i++)b(3.241,y+.08+i*.024,z+.055,.006,.006,.16,grey);return}for(let i=0;i<count;i++){const zz=z+.135+(i-(count-1)/2)*.105,cy=y+.15;for(let side of [-1,1]){const wing=new T.Mesh(new T.SphereGeometry(1,12,10),mat(color));wing.scale.set(.008,.047/count,.043/count);wing.position.set(3.235,cy,zz+side*.032/count);study.add(wing)}b(3.223,cy-.035,zz-.004,.008,.07,.008,dark)}}
 function cup(z,y){b(3.1,y,z-.07,.12,.045,.14,dark);cyl(3.16,y+.045,z,.022,.09,gold,study);const o=new T.Mesh(new T.ConeGeometry(.065,.11,24,1,true),gold);o.rotation.z=Math.PI;o.position.set(3.16,y+.19,z);study.add(o);for(let side of [-1,1]){const h=new T.Mesh(new T.TorusGeometry(.045,.009,8,20),gold);h.rotation.y=Math.PI/2;h.position.set(3.16,y+.18,z+side*.066);study.add(h)}}
 frame(2.55,1.81,'#d8ba57');frame(2.35,1.37,'#4f9dca');frame(2.76,1.37,'#b79058',2);cup(2.49,.93);frame(2.76,.93,'#c77b3e');frame(2.35,.49,'',1,true);cup(2.91,.49);
 // Public spaces use the approved plan-20 coordinates, in metres.
 const cream=mat('#ece8df'),sage=mat('#a6ada0'),stone=mat('#bdbeb8'),warmOak=mat('#c9b18e'),seam=mat('#aa967b');
 function lowCab(x,z,w,d,h=.82){box(x,0,z,w,h,d,warmOak);box(x,h,z,w,.025,d,cream);const count=Math.max(1,Math.round(Math.max(w,d)/.55));for(let i=1;i<count;i++){if(w>d)box(x+w*i/count,h*.05,z-.003,.009,h*.9,.008,seam);else box(x-.003,h*.05,z+d*i/count,.008,h*.9,.009,seam)}}
 function vase(x,y,z){cyl(x,y,z,.065,.17,cream);for(let i=0;i<4;i++)line3([x,y+.1,z],[x+(i-1.5)*.04,y+.32+(i%2)*.06,z+.035*(i%2)],.004,sage)}
 function books(x,y,z,alongX,count){for(let i=0;i<count;i++)box(x+(alongX?i*.045:0),y,z+(alongX?0:i*.045),alongX?.035:.2,.17+(i%3)*.025,alongX?.2:.035,[cream,grey,warmOak][i%3])}
 // TV wall: closed cabinet back is directly against the original suite wall.
 box(7.45,0,1.8,.5,.32,4.55,warmOak);box(7.45,.32,1.8,.035,2.15,4.55,warmOak);
 for(const zz of [1.8,5.55]){box(7.45,.32,zz,.5,2.15,.035,warmOak);for(const yy of [.7,1.15,1.65,2.12])box(7.45,yy,zz,.5,.025,.72,cream);books(7.65,.725,zz+.08,false,9)}
 box(7.49,.65,2.57,.35,1.55,2.78,warmOak);round(7.845,.78,2.72,.045,1.28,2.38,dark,.018);
 // Ivory sofa, back against independent divider (not the exterior wall).
 round(10.6,.12,2.2,1,.25,3.05,cream,.1);round(11.34,.3,2.2,.25,.6,3.05,cream,.1);
 for(const z of [2.2,5.02])round(10.6,.3,z,1,.48,.23,cream,.09);
 for(const z of [2.46,3.3,4.14]){round(10.64,.36,z,.7,.19,.8,cream,.07);round(11.12,.52,z+.09,.2,.35,.58,z===3.3?sage:cream,.07)}
 box(8.05,.003,2,3.45,.012,3.55,mat('#d6d1c6'));
 for(const [x,z,w,d,h]of [[9,3.05,1,.65,.4],[9.65,3.5,.62,.52,.34]]){cyl(x+w/2,.03,z+d/2,.17,h-.03,cream);round(x,h,z,w,.06,d,cream,.025)}vase(9.45,.46,3.35);
 round(8.7,.12,.9,.8,.3,.82,cream,.14);round(8.7,.42,.9,.8,.42,.18,cream,.07);round(8.7,.42,1.05,.12,.25,.57,cream,.05);round(9.38,.42,1.05,.12,.25,.57,cream,.05);
 cyl(10.89,.02,1.82,.22,.45,warmOak);cyl(9.75,.01,1.1,.19,.03,dark);cyl(9.75,.04,1.1,.015,1.4,dark);cyl(9.75,1.44,1.1,.18,.25,cream);
 box(11.7,0,1.4,.12,2.65,3.9,warmOak,walls);box(11.82,.9,2.5,.12,.04,1.2,warmOak);vase(11.88,.94,3.05);
 box(11.825,1.2,2.65,.015,.85,.85,warmOak,walls);box(11.845,1.24,2.69,.008,.77,.77,cream,walls);
 // Six-seat oval dining table, two sculptural pedestal feet.
 for(const z of [7.35,8.35])round(9.63,.03,z,.54,.67,.36,cream,.12);round(9.4,.7,7,1,.07,1.9,cream,.034);
 function diningChair(x,z,rot){const g=new T.Group();g.position.set(x+.24,0,z+.25);g.rotation.y=rot;root.add(g);for(const xx of [-.17,.17])for(const zz of [-.17,.17])line3([xx,.03,zz],[xx*.9,.44,zz*.9],.022,warmOak,g);round(-.24,.43,-.25,.48,.07,.5,cream,.032,g);round(-.24,.49,.18,.48,.35,.08,cream,.035,g)}
 for(const z of [7.25,8.15]){diningChair(8.8,z,-Math.PI/2);diningChair(10.5,z,Math.PI/2)}diningChair(9.65,6.42,Math.PI);diningChair(9.65,9,0);vase(9.9,.77,7.95);
 // Wall display/storage cabinet: opaque lower doors, open shelves and lattice tower.
 lowCab(12.55,8.9,.45,4.1);box(12.965,.85,8.9,.035,1.5,4.1,cream);
 for(const yy of [1.25,1.78,2.3])box(12.57,yy,8.9,.4,.035,2.7,warmOak);
 for(const zz of [9.1,10.05,10.95]){books(12.65,1.29,zz,false,5);vase(12.73,1.815,zz+.15)}
 box(12.55,.85,11.65,.45,1.5,.04,warmOak);box(12.55,2.32,11.65,.45,.04,1.35,warmOak);
 for(let z=11.7;z<13;z+=.12)box(12.55,.85,z,.025,1.5,.025,warmOak);
 // Entry storage and right-hand shoe bench fitted into the kitchen side-wall corner.
 lowCab(2.45,10.87,4.43,.42,.86);round(1.6,.03,13.55,1.2,.34,.45,warmOak,.025);round(1.6,.37,13.55,1.2,.08,.45,cream,.035);
 // 1.8 m screen, double-sided low cabinets, open at both ends.
 lowCab(7.98,11.2,.35,1.8,.76);lowCab(8.43,11.2,.35,1.8,.76);
 for(const z of [11.2,12.96])box(8.33,.76,z,.1,1.68,.04,warmOak);box(8.33,2.4,11.2,.1,.04,1.8,warmOak);
 for(let z=11.3;z<13;z+=.1)box(8.35,.78,z,.06,1.62,.025,warmOak);
 box(8.32,.84,11.65,.12,1.5,.9,cream);
 // Canvas panels: stylised mountains on the entry face; flowering branches on reverse.
 function artTexture(reverse){const c=document.createElement('canvas');c.width=256;c.height=440;const ctx=c.getContext('2d');ctx.fillStyle='#e9e1d0';ctx.fillRect(0,0,256,440);if(!reverse){for(let k=0;k<4;k++){ctx.fillStyle=['#c4c3b3','#a7b0a3','#909e92','#74897c'][k];ctx.beginPath();ctx.moveTo(0,440);for(let x=0;x<=256;x+=8)ctx.lineTo(x,150+k*55+Math.sin(x*.025+k)*50+Math.cos(x*.07)*16);ctx.lineTo(256,440);ctx.fill()}}else{ctx.strokeStyle='#7d7861';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(50,440);ctx.bezierCurveTo(180,310,90,170,210,20);ctx.stroke();for(let i=0;i<13;i++){const x=85+(i*47%130),y=45+i*27;ctx.fillStyle=i%3?'#f8f3e7':'#a5ae8f';ctx.beginPath();ctx.ellipse(x,y,14,7,i,0,Math.PI*2);ctx.fill()}}const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;return new T.MeshStandardMaterial({map:tex,side:T.DoubleSide})}
 for(const [x,rev]of [[8.315,false],[8.445,true]]){const panel=new T.Mesh(new T.PlaneGeometry(.86,1.46),artTexture(rev));panel.rotation.y=rev?Math.PI/2:-Math.PI/2;panel.position.set(x,1.59,12.1);root.add(panel)}
 vase(8.12,.785,11.45);vase(8.62,.785,12.7);
 // Solid, plain grey island. No glass, no stools, no marble texture.
 round(9.88,.04,11.2,.85,.82,1.8,warmOak,.025);round(9.86,.86,11.18,.89,.055,1.84,stone,.025);for(const z of [11.8,12.4])box(10.732,.12,z,.006,.62,.008,seam);vase(10.3,.915,11.65);
 // Final balcony: straight beige chaise and low bookcase, clear right-hand laundry route.
 round(7.6,.1,-1.5,1.65,.26,.92,cream,.09);round(7.6,.36,-1.5,.2,.55,.92,cream,.08);round(7.81,.36,-1.47,1.41,.15,.86,cream,.06);round(7.8,.51,-1.37,.25,.33,.62,cream,.07);
 box(7.95,.03,-2.5,2,.06,.3,warmOak);box(7.95,.65,-2.5,2,.04,.3,warmOak);for(const x of [7.95,8.6,9.25,9.92])box(x,.09,-2.5,.03,.56,.3,warmOak);box(7.95,.09,-2.5,2,.56,.025,warmOak);books(8.02,.1,-2.44,true,11);books(8.68,.1,-2.44,true,10);books(9.33,.1,-2.44,true,10);
 cyl(7.7,.01,-1.95,.15,.025,dark);line3([7.7,.03,-1.95],[7.7,1.45,-1.95],.012,dark);line3([7.7,1.45,-1.95],[7.95,1.45,-1.95],.012,dark);cyl(7.95,1.27,-1.95,.06,.2,dark);


 // Kitchen plan02, origin at original north-west corner. No footprint changes.
 const kitchen=new T.Group();kitchen.name='kitchen-furniture';kitchen.position.set(2.8,0,13.6);root.add(kitchen);
 const kb=(x,y,z,w,h,d,m=warmOak)=>box(x,y,z,w,h,d,m,kitchen);
 const kr=(x,y,z,w,h,d,m=cream,r=.02)=>round(x,y,z,w,h,d,m,r,kitchen);
 const steel=mat('#bac0c1',.28),basin=mat('#7d898d',.24);
 // Refrigerator and both towers face east into the central work area.
 kr(.05,0,.05,.75,2.15,.9,steel,.035);
 kb(.802,.72,.06,.006,.012,.88,dark);kb(.802,.74,.5,.006,1.38,.008,dark);
 for(const z of [.44,.56])kb(.82,1.02,z,.035,.65,.018,steel);
 kb(0,0,1,.65,2.55,.6);kb(0,0,1.6,.65,2.55,.6);
 kb(.651,.77,1.03,.016,.62,.54,dark);kb(.672,1.28,1.08,.028,.025,.44,steel);
 kb(.67,1.07,1.66,.018,.6,.018,dark);
 // Main counters, 0.88m high; dishwasher sits below continuous worktop.
 kb(0,0,2.2,4.2,.84,.6);kb(3.6,0,0,.6,.84,2.2);
 kb(0,.84,2.2,1.87,.04,.6,cream);kb(2.53,.84,2.2,1.67,.04,.6,cream);
 kb(1.87,.84,2.2,.66,.04,.10,cream);kb(1.87,.84,2.72,.66,.04,.08,cream);
 kb(3.6,.84,0,.6,.04,2.2,cream);
 kb(1.2,.07,2.187,.6,.72,.018,steel);kb(1.25,.72,2.17,.5,.025,.025,dark);
 for(const x of [.65,1.2,1.8,2.6,3.1,3.6])kb(x,.05,2.19,.008,.75,.006,seam);
 for(const y of [.28,.56])kb(3.59,y,.04,.008,.008,2.12,seam);
 // Recessed sink and faucet, visible from overhead without blocking worktop.
 kb(1.87,.68,2.3,.66,.025,.42,basin);
 kb(1.87,.70,2.3,.02,.14,.42,steel);kb(2.51,.70,2.3,.02,.14,.42,steel);
 kb(1.87,.7,2.3,.66,.14,.02,steel);kb(1.87,.7,2.7,.66,.14,.02,steel);
 line3([2.2,.88,2.75],[2.2,1.22,2.75],.016,steel,kitchen);line3([2.2,1.22,2.75],[2.2,1.22,2.55],.016,steel,kitchen);
 kr(.72,.88,2.35,.36,.29,.35,white,.055);kb(.81,1.03,2.345,.16,.025,.01,dark);
 // Two burners, aligned along right wall, and closed ivory upper cabinets.
 kb(3.65,.885,.85,.50,.025,.8,dark);
 for(const z of [1.03,1.47]){cyl(3.9,.91,z,.11,.025,steel,kitchen);cyl(3.9,.935,z,.075,.018,dark,kitchen);kb(3.77,.95,z-.012,.26,.012,.024,dark);kb(3.888,.95,z-.13,.024,.012,.26,dark);}
 kb(3.65,1.68,.81,.55,.12,.88,steel);
 kb(3.87,1.8,0,.33,.75,2.2,cream);
 for(const z of [.55,1.1,1.65])kb(3.863,1.82,z,.006,.7,.008,seam);


 // Laundry final: north-west tall cabinet, north worktop, east sink + vertical stack.
 const laundry=new T.Group();laundry.name='laundry-furniture';laundry.position.set(13,0,-1.8);root.add(laundry);
 const lb=(x,y,z,w,h,d,m=warmOak)=>box(x,y,z,w,h,d,m,laundry);
 lb(0,.002,0,2.8,.012,1.8,mat('#d4c9b7'));
 lb(.04,0,.03,.48,2.55,.55);lb(.07,.85,.585,.018,.65,.025,dark);
 lb(.52,0,.03,2.25,.84,.55);lb(.52,.84,.03,2.25,.04,.55,cream);
 for(const x of [1.05,1.6,2.1])lb(x,.05,.582,.008,.75,.008,seam);
 // Sink base on east wall. Counter is cut out around basin rather than covering it.
 lb(2.1,0,.58,.67,.84,.52);
 lb(2.1,.84,.58,.08,.04,.52,cream);lb(2.69,.84,.58,.08,.04,.52,cream);
 lb(2.18,.84,.58,.51,.04,.06,cream);lb(2.18,.84,1.04,.51,.04,.06,cream);
 lb(2.18,.66,.64,.51,.025,.40,basin);
 lb(2.18,.685,.64,.015,.155,.40,steel);lb(2.675,.685,.64,.015,.155,.40,steel);
 lb(2.18,.685,.64,.51,.155,.015,steel);lb(2.18,.685,1.025,.51,.155,.015,steel);
 line3([2.73,.88,.82],[2.73,1.2,.82],.014,steel,laundry);line3([2.73,1.2,.82],[2.51,1.2,.82],.014,steel,laundry);
 // Two closed front loaders stacked on one footprint, both face west.
 for(const y of [.04,.91]){
 round(2.1,y,1.1,.67,.85,.67,white,.025,laundry);
 lb(2.089,y+.67,1.12,.018,.13,.63,cream);lb(2.075,y+.7,1.43,.012,.065,.24,dark);
 const door=new T.Mesh(new T.CylinderGeometry(.225,.225,.025,40),dark);door.rotation.z=Math.PI/2;door.position.set(2.079,y+.37,1.435);laundry.add(door);
 const ring=new T.Mesh(new T.TorusGeometry(.23,.018,12,40),steel);ring.rotation.y=Math.PI/2;ring.position.set(2.06,y+.37,1.435);laundry.add(ring);
 }
 for(const yy of [.88,.935])round(1.28,yy,.19,.42,.05,.25,white,.018,laundry);
 // Roller blind above the original exterior window.
 lb(.6,2.1,.015,1.6,.23,.035,cream);


 // Public bathroom: NW local origin; closed entry is retained from the house plan.
 const pb=new T.Group();pb.name='publicbath-furniture';pb.position.set(2.3,0,8.1);root.add(pb);
 const bb=(x,y,z,w,h,d,m=warmOak)=>box(x,y,z,w,h,d,m,pb);
 const tile=mat('#d8c9b7'),porcelain=mat('#faf8f2',.22);
 bb(0,.003,0,2.2,.012,2.75,tile);
 for(let x=.55;x<2.2;x+=.55)bb(x,.016,0,.004,.002,2.75,seam);
 for(let z=.55;z<2.75;z+=.55)bb(0,.016,z,2.2,.002,.004,seam);
 bb(1.65,.23,.15,.55,.53,1.2);
 // Four counter strips around recessed basin.
 bb(1.65,.76,.15,.55,.07,.26,cream);bb(1.65,.76,1.04,.55,.07,.31,cream);
 bb(1.65,.76,.41,.08,.07,.63,cream);bb(2.07,.76,.41,.13,.07,.63,cream);
 bb(1.73,.65,.41,.34,.025,.63,porcelain);
 bb(1.73,.675,.41,.012,.09,.63,porcelain);bb(2.058,.675,.41,.012,.09,.63,porcelain);
 bb(1.73,.675,.41,.34,.09,.012,porcelain);bb(1.73,.675,1.028,.34,.09,.012,porcelain);
 line3([2.14,.83,.73],[2.14,1.06,.73],.014,steel,pb);line3([2.14,1.06,.73],[1.96,1.06,.73],.014,steel,pb);
 cyl(2.1,.83,1.16,.036,.13,dark,pb);
 bb(2.15,1.05,.17,.035,1.0,1.16,new T.MeshStandardMaterial({color:'#b8c2c0',metalness:.85,roughness:.15}));
 round(.04,.08,1.04,.2,.67,.56,porcelain,.04,pb);
 round(.19,.04,1.09,.49,.38,.47,porcelain,.13,pb);
 round(.17,.42,1.06,.56,.045,.53,porcelain,.02,pb);
 bb(.02,.69,.91,.08,.025,.13,steel);cyl(.08,.57,.98,.055,.12,white,pb);
 bb(0,.02,1.8,2.2,.025,.95,tile);
 bb(0,.045,1.79,2.2,.025,.045,steel);bb(0,2.07,1.79,2.2,.035,.045,steel);
 bb(.02,.07,1.8,1.13,2,.012,glass);bb(1.05,.07,1.82,1.13,2,.012,glass);
 for(const x of [.02,1.1,2.17])bb(x,.07,1.8,.015,2,.015,steel);
 line3([1.08,.92,1.78],[1.08,1.17,1.78],.012,steel,pb);
 line3([.06,.9,2.45],[.06,2.08,2.45],.014,steel,pb);line3([.06,2.08,2.45],[.35,2.08,2.45],.014,steel,pb);
 cyl(.35,2.05,2.45,.12,.025,steel,pb);bb(.18,.047,2.55,.11,.005,.11,steel);

 addStorage({T,root,box,round,cyl,mat});
 addFatherStudy({T,root,box,round,cyl,line3,mat,glass,dark,steel});
 addArtStudio({T,root,box,round,cyl,line3,mat,oak,white,grey,glass,dark,steel});
 addParents({T,root,box,round,cyl,line3,mat,oak,white,grey,glass,dark,steel});
 let angle=.2,elev=1.0,dist=37,target=new T.Vector3(8,.1,6.3),desired=target.clone(),drag=null,moved=0,pinch=0,pointers=new Map(),wallLow=true,multi=false;
 const api={auto:false,panMode:false,togglePan(){this.panMode=!this.panMode;return this.panMode},view:'house',setView(v){this.view=v;this.auto=false;const p=v==='storage'?[5.95,.3,9.475,7.5,.1,1.12]:v==='fatherstudy'?[15.1,.35,4.05,8.5,-1.57,1.12]:v==='artstudio'?[15.1,.35,1.4,9,.1,1.12]:v==='parents'?[15.8,.35,8.6,14,.12,1.12]:v==='publicbath'?[3.4,.3,9.475,7.6,.1,1.14]:v==='laundry'?[14.4,.35,-.9,6.8,.2,1.12]:v==='kitchen'?[4.9,.4,15,9,.1,1.1]:v==='living'?[10.2,.4,5.6,19,.25,1.05]:v==='entry'?[8.2,.4,12,14,.35,1.05]:v==='balcony'?[10,.3,-1.2,10,.1,1.05]:v==='guest'?[.15,.35,9.85,8.7,.15,1.05]:v==='study'?[5.6,.5,-.2,7.7,1.2,.95]:v==='bedroom'?[3.4,.35,4.4,14,.2,.95]:[8,.1,6.3,37,.2,1.0];desired.set(...p.slice(0,3));target.copy(desired);dist=p[3];angle=p[4];elev=p[5]},scale(f){dist=Math.min(65,Math.max(4,dist/f))},reset(){this.setView(this.view)},focus(){this.setView('bedroom')},top(){elev=1.565;angle=0},toggleWalls(){wallLow=!wallLow;walls.scale.y=wallLow?.3:1;return wallLow},toggleLabels(){labels.visible=!labels.visible;return labels.visible}};walls.scale.y=.3;
 const el=renderer.domElement,ray=new T.Raycaster(),mouse=new T.Vector2();
 function pan(dx,dy){camera.updateMatrixWorld();const unit=2*camera.position.distanceTo(target)*Math.tan(camera.fov*Math.PI/360)/Math.max(1,host.clientHeight);const right=new T.Vector3().setFromMatrixColumn(camera.matrixWorld,0),up=new T.Vector3().setFromMatrixColumn(camera.matrixWorld,1);target.addScaledVector(right,-dx*unit).addScaledVector(up,dy*unit)}
 el.onpointerdown=e=>{el.setPointerCapture(e.pointerId);if(!pointers.size){moved=0;multi=false}pointers.set(e.pointerId,[e.clientX,e.clientY]);drag=[e.clientX,e.clientY];if(pointers.size>=2){multi=true;drag=null;const a=[...pointers.values()];pinch=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1])}};
 el.onpointermove=e=>{if(!pointers.has(e.pointerId))return;const before=[...pointers.values()];pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===2){const a=[...pointers.values()],d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);pan((a[0][0]+a[1][0]-before[0][0]-before[1][0])/2,(a[0][1]+a[1][1]-before[0][1]-before[1][1])/2);if(pinch>0&&d>0)api.scale(d/pinch);pinch=d;drag=null;moved=100}else if(drag){const dx=e.clientX-drag[0],dy=e.clientY-drag[1];moved+=Math.abs(dx)+Math.abs(dy);if(api.panMode||e.shiftKey||e.buttons===2)pan(dx,dy);else{angle-=dx*.008;elev=Math.max(.22,Math.min(1.565,elev+dy*.006))}drag=[e.clientX,e.clientY]}};
 function release(e,cancel=false){if(!cancel&&!multi&&moved<5&&pointers.size===1){const rect=el.getBoundingClientRect();mouse.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);ray.setFromCamera(mouse,camera);const hit=ray.intersectObjects(targets)[0];if(hit){const n=hit.object.userData.room.n;if(n==='储物间①')onPick('storage');else if(n==='爸爸的书房')onPick('fatherstudy');else if(n==='妈妈的画室')onPick('artstudio');else if(/^父母/.test(n))onPick('parents');else if(n==='公卫')onPick('publicbath');else if(n==='洗衣房')onPick('laundry');else if(n==='厨房')onPick('kitchen');else if(n==='景观阳台')onPick('balcony');else if(/玄关连接|入户餐厅连接|^玄关$/.test(n))onPick('entry');else if(/客厅|^餐厅$|餐厅通行/.test(n))onPick('living');else if(n==='客卧')onPick('guest');else if(n==='许今闻书房')onPick('study');else if(/许今闻卧室|许今闻独卫|许今闻衣帽间/.test(n))onPick('bedroom');else{const r=hit.object.userData.room;target.set(r.x+r.w/2,.2,r.y+r.h/2);dist=Math.max(r.w,r.h)*2.8;api.auto=false}}}pointers.delete(e.pointerId);drag=pointers.size===1?[...pointers.values()][0]:null;pinch=0;if(!pointers.size)multi=false}
 el.onpointerup=e=>release(e);el.onpointercancel=e=>release(e,true);el.oncontextmenu=e=>e.preventDefault();el.addEventListener('wheel',e=>{e.preventDefault();api.scale(e.deltaY<0?1.08:1/1.08)},{passive:false});
 function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}new ResizeObserver(resize).observe(host);resize();let previous=0;function tick(now){requestAnimationFrame(tick);if(!isActive())return;const dt=Math.min((now-previous)/1000,.05);previous=now;if(api.auto)angle+=dt*.18;const adjusted=dist*Math.max(1,1/camera.aspect);camera.position.set(target.x+Math.sin(angle)*Math.cos(elev)*adjusted,target.y+Math.sin(elev)*adjusted,target.z+Math.cos(angle)*Math.cos(elev)*adjusted);camera.lookAt(target);renderer.render(scene,camera)}requestAnimationFrame(tick);return api;
}
