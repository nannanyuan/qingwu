(()=>{'use strict';
const $=s=>document.querySelector(s),canvas=$('#view'),stage=$('#scene'),nodes=window.ROOM_PANORAMAS,byId=new Map(nodes.map(x=>[x.id,x]));
const pointers=new Map(),cache=new Map(),saved=new Map(),clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),wrap=x=>Math.atan2(Math.sin(x),Math.cos(x));
let gl,program,texture,viewLoc,raf=false,ready=false,contextLost=false,loading=false,current=null,yaw=0,pitch=0,fov=65,request=0;
function constrain(){yaw=wrap(yaw);pitch=clamp(pitch,-Math.PI/2+.015,Math.PI/2-.015);fov=clamp(fov,42,85);}
function draw(){if(raf||!ready||contextLost)return;raf=true;requestAnimationFrame(()=>{raf=false;constrain();gl.viewport(0,0,canvas.width,canvas.height);gl.uniform4f(viewLoc,yaw,pitch,Math.tan(fov*Math.PI/360),canvas.width/canvas.height);gl.drawArrays(gl.TRIANGLES,0,6);});}
function resize(){const d=Math.min(devicePixelRatio||1,2);canvas.width=Math.max(1,Math.round(stage.clientWidth*d));canvas.height=Math.max(1,Math.round(stage.clientHeight*d));draw();}
function defaultFov(){return stage.clientWidth<700?75:62;}

function setupGL(){
 gl=canvas.getContext('webgl',{alpha:false,antialias:false,powerPreference:'low-power'});
 if(!gl)throw Error('此浏览器未能开启全景显示，请换用支持 WebGL 的浏览器。');
 const compile=(type,source)=>{const sh=gl.createShader(type);gl.shaderSource(sh,source);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh;};
 const vs='attribute vec2 p;varying vec2 v;void main(){v=p;gl_Position=vec4(p,0.,1.);}';
 const fs='precision highp float;varying vec2 v;uniform sampler2D tex;uniform vec4 view;void main(){vec3 d=normalize(vec3(v.x*view.w*view.z,v.y*view.z,1.));float cy=cos(view.x),sy=sin(view.x),cp=cos(view.y),sp=sin(view.y);d=vec3(d.x,d.y*cp+d.z*sp,d.z*cp-d.y*sp);d=vec3(d.x*cy+d.z*sy,d.y,d.z*cy-d.x*sy);vec2 uv=vec2(fract(atan(d.x,d.z)/6.28318530718+.5),.5-asin(clamp(d.y,-1.,1.))/3.14159265359);gl_FragColor=texture2D(tex,uv);}';
 program=gl.createProgram();gl.attachShader(program,compile(gl.VERTEX_SHADER,vs));gl.attachShader(program,compile(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
 const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);const a=gl.getAttribLocation(program,'p');gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);
 texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.uniform1i(gl.getUniformLocation(program,'tex'),0);viewLoc=gl.getUniformLocation(program,'view');
}
function upload(img){gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,img);if(gl.getError()!==gl.NO_ERROR)throw Error('图片无法上传到图形设备，请刷新重试。');}

function hint(t){$('#status').textContent=t;$('#status').hidden=!t;}
function imageFor(n){if(cache.has(n.id)){const p=cache.get(n.id);cache.delete(n.id);cache.set(n.id,p);return p;}const p=new Promise((resolve,reject)=>{const im=new Image(),timer=setTimeout(()=>reject(Error('图片加载超时，请重试')),30000);im.onload=()=>{clearTimeout(timer);resolve(im);};im.onerror=()=>{clearTimeout(timer);reject(Error('图片未加载，请重试'));};im.src=n.image;});cache.set(n.id,p);p.catch(()=>{if(cache.get(n.id)===p)cache.delete(n.id)});while(cache.size>3)cache.delete(cache.keys().next().value);return p;}
async function choose(id){if(!byId.has(id))return false;const n=byId.get(id),token=++request;loading=true;pointers.clear();hint('正在加载'+n.name);$('#error').hidden=true;stage.classList.add('loading');
 try{const im=await imageFor(n);if(token!==request)return false;if(contextLost)throw Error('画面暂时中断，请稍后重试');if(current)saved.set(current.id,{yaw,pitch,fov});upload(im);current=n;const state=saved.get(id);yaw=state?.yaw??0;pitch=state?.pitch??0;fov=state?.fov??defaultFov();ready=true;loading=false;$('#name').textContent=n.name;$('#room-select').value=id;$('#back').href='index.html#room='+n.group;document.title=n.name+' · 360°全景';history.replaceState(null,'','#'+id);stage.classList.remove('loading');hint('');resize();return true;
 }catch(e){if(token!==request)return false;loading=false;stage.classList.remove('loading');hint('');$('#error-text').textContent=e.message;$('#error').hidden=false;return false;}}
for(const n of nodes){const o=document.createElement('option');o.value=n.id;o.textContent=n.name;$('#room-select').append(o);}
$('#room-select').addEventListener('change',e=>choose(e.target.value));
const dismiss=()=>{$('#hint').hidden=true;};setTimeout(dismiss,5000);
canvas.addEventListener('pointerdown',e=>{if(e.button>0)return;canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});dismiss();});
canvas.addEventListener('pointermove',e=>{const old=pointers.get(e.pointerId);if(!old||loading)return;const now={x:e.clientX,y:e.clientY};if(pointers.size===1){yaw-=(now.x-old.x)/stage.clientHeight*fov*Math.PI/180;pitch+=(now.y-old.y)/stage.clientHeight*fov*Math.PI/180;}else{const other=[...pointers.entries()].find(([id])=>id!==e.pointerId)?.[1];if(other){const before=Math.hypot(old.x-other.x,old.y-other.y),after=Math.hypot(now.x-other.x,now.y-other.y);if(before>5&&after>5)fov*=before/after;}}pointers.set(e.pointerId,now);draw();});
['pointerup','pointercancel','lostpointercapture'].forEach(t=>canvas.addEventListener(t,e=>pointers.delete(e.pointerId)));
canvas.addEventListener('wheel',e=>{e.preventDefault();fov+=e.deltaY*.025;dismiss();draw();},{passive:false});
$('#reset').addEventListener('click',()=>{yaw=0;pitch=0;fov=defaultFov();draw();});
$('#full').hidden=!stage.requestFullscreen;$('#full').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await stage.requestFullscreen();}catch{hint('已铺满页面，可横屏查看');setTimeout(()=>hint(''),2500)}});
$('#retry').addEventListener('click',()=>{try{if(!gl)setupGL();choose($('#room-select').value||nodes[0].id);}catch(e){$('#error-text').textContent=e.message;}});
window.addEventListener('hashchange',()=>{const id=location.hash.slice(1);if(byId.has(id)&&id!==current?.id)choose(id)});
document.addEventListener('keydown',e=>{if(e.target.matches('button,a,select,input'))return;switch(e.key){case'ArrowLeft':yaw-=.12;break;case'ArrowRight':yaw+=.12;break;case'ArrowUp':pitch+=.1;break;case'ArrowDown':pitch-=.1;break;case'+':case'=':fov-=4;break;case'-':fov+=4;break;default:return;}e.preventDefault();dismiss();draw();});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();contextLost=true;++request;loading=false;hint('正在恢复画面…')});
canvas.addEventListener('webglcontextrestored',async()=>{try{setupGL();contextLost=false;const id=current?.id||$('#room-select').value||nodes[0].id;await choose(id);}catch(e){hint(e.message)}});
new ResizeObserver(resize).observe(stage);document.addEventListener('fullscreenchange',resize);
window.room360={choose,state:()=>({id:current?.id,yaw,pitch,fov,ready,loading,cached:cache.size})};
const initial=byId.has(location.hash.slice(1))?location.hash.slice(1):nodes[0].id;$('#room-select').value=initial;
try{setupGL();resize();choose(initial);}catch(e){$('#error-text').textContent=e.message;$('#error').hidden=false;}
})();
