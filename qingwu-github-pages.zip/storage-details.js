// Coordinates follow whole-house plan: x east, z south; east door untouched.
export function addStorage({T,root,box,round,cyl,mat}){
 const g=new T.Group();g.name='storage-furniture';g.position.set(4.5,0,8.1);root.add(g);
 const oak=mat('#c5ad88'),ivory=mat('#e9e4d8'),grey=mat('#aaa79e'),dark=mat('#424744'),tile=mat('#d6d0c5');
 const b=(x,y,z,w,h,d,m=oak)=>box(x,y,z,w,h,d,m,g);
 const r=(x,y,z,w,h,d,m=grey)=>round(x,y,z,w,h,d,m,.025,g);
 // West: full-depth storage, shelves face east.
 b(.02,.06,.02,.51,.07,2.71);b(.02,2.36,.02,.51,.04,2.71);b(.02,.13,.02,.025,2.23,2.71);
 for(const z of [.02,.91,1.82,2.71])b(.02,.13,z,.51,2.23,.025);
 for(const y of [.88,1.28,1.68,2.02])b(.02,y,.02,.51,.025,2.71);
 for(let j=0;j<3;j++){b(.53,2.05,.04+j*.90,.02,.30,.85,ivory);for(let k=0;k<2;k++)r(.11,1.32+k*.40,.10+j*.90,.36,.26,.66,j===0?ivory:grey);}
 // Exactly two luggage cases in bottom compartments.
 for(const [z,m]of [[1.06,dark],[1.96,ivory]]){r(.12,.17,z,.32,.61,.55,m);b(.22,.79,z+.18,.12,.07,.18,dark);for(const zz of [z+.05,z+.46])cyl(.3,.12,zz,.035,.05,dark,g);}
 r(.1,.17,.12,.38,.30,.67,grey);
 // North shallow supply run and south sorting run stop x=2.05.
 for(const [z,d,isSouth]of [[.02,.33,false],[2.30,.43,true]]){
 b(.55,.08,z,1.5,.74,d,ivory);b(.55,.82,z,1.5,.035,d,isSouth?tile:oak);
 for(let i=0;i<3;i++){const x=.57+i*.5;const front=isSouth?z-.012:z+d;b(x,.12,front,.46,.65,.018,ivory);b(x+.22,.57,front-.01,.025,.04,.035,oak);}
 const back=isSouth?2.71:.02;b(.55,1.05,back,1.5,1.31,.025);
 for(const x of [.55,1.29,2.025])b(x,1.05,z,.025,1.31,d);
 for(const y of [1.08,1.50,1.92,2.34])b(.55,y,z,1.5,.025,d);
 for(let row=0;row<3;row++)for(let j=0;j<3;j++)r(.62+j*.45,1.12+row*.42,z+.04,.34,.25,d-.08,(row+j)%2?ivory:grey);
 }
 return g;
}
